# Hirepoles Consultancy Services Pvt. Ltd Website

This is a Next.js + TailwindCSS project for Hirepoles Consultancy Services Pvt. Ltd.

## Run locally
```bash
npm install
npm run dev
```

## Deploy
Connect to Vercel or Netlify for free hosting.
